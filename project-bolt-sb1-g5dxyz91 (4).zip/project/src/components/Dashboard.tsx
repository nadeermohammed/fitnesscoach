import React from 'react';
import { ScanHistory } from '../App';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, 
  LineChart, Line 
} from 'recharts';
import { AlertTriangle, Shield, Calendar, Clock, Search } from 'lucide-react';

interface DashboardProps {
  scanHistory: ScanHistory;
}

export const Dashboard: React.FC<DashboardProps> = ({ scanHistory }) => {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  const getThreatLevel = (score: number) => {
    if (score >= 80) return { level: 'High', color: 'text-red-600', bgColor: 'bg-red-100' };
    if (score >= 50) return { level: 'Medium', color: 'text-yellow-600', bgColor: 'bg-yellow-100' };
    return { level: 'Low', color: 'text-green-600', bgColor: 'bg-green-100' };
  };

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center mb-4">
            <Search size={20} className="text-purple-600 mr-3" />
            <h3 className="text-lg font-medium">Total Scans</h3>
          </div>
          <div className="text-3xl font-bold">{scanHistory.totalScans}</div>
          <div className="mt-2 text-sm text-gray-500">Across all users and projects</div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center mb-4">
            <AlertTriangle size={20} className="text-red-600 mr-3" />
            <h3 className="text-lg font-medium">Detected Threats</h3>
          </div>
          <div className="text-3xl font-bold">{scanHistory.detectedThreats}</div>
          <div className="mt-2 text-sm text-gray-500">
            {Math.round((scanHistory.detectedThreats / scanHistory.totalScans) * 100)}% of total scans
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center mb-4">
            <Clock size={20} className="text-blue-600 mr-3" />
            <h3 className="text-lg font-medium">Average Scan Time</h3>
          </div>
          <div className="text-3xl font-bold">1.2s</div>
          <div className="mt-2 text-sm text-gray-500">Per image analysis</div>
        </div>
      </div>
      
      {/* Recent Scans */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-medium">Recent Scans</h3>
          <button className="text-purple-600 text-sm font-medium hover:text-purple-800">
            View All
          </button>
        </div>
        
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">File</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Threat Level</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Manipulation Type</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {scanHistory.recentScans.map((scan) => {
                const threatInfo = getThreatLevel(scan.threatScore);
                const dominantManipulation = Object.entries(scan.manipulationTypes)
                  .sort((a, b) => b[1] - a[1])[0];
                
                return (
                  <tr key={scan.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="h-10 w-10 flex-shrink-0">
                          <img 
                            className="h-10 w-10 rounded-md object-cover"
                            src={scan.originalImage}
                            alt={scan.filename}
                          />
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-900">
                            {scan.filename}
                          </div>
                          <div className="text-sm text-gray-500">
                            ID: {scan.id}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">
                        {new Date(scan.timestamp).toLocaleDateString()}
                      </div>
                      <div className="text-sm text-gray-500">
                        {new Date(scan.timestamp).toLocaleTimeString()}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${threatInfo.bgColor} ${threatInfo.color}`}>
                        {threatInfo.level} ({scan.threatScore}%)
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 capitalize">
                      {dominantManipulation ? `${dominantManipulation[0]} (${Math.round(dominantManipulation[1] * 100)}%)` : 'N/A'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <a href="#" className="text-purple-600 hover:text-purple-900 mr-3">View</a>
                      <a href="#" className="text-purple-600 hover:text-purple-900">Report</a>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
