import React, { useState } from 'react';
import { ScanResult } from '../App';
import { 
  AlertTriangle, 
  Shield, 
  ArrowLeft, 
  Download, 
  Share2, 
  Info, 
  CheckCircle2, 
  XCircle
} from 'lucide-react';

interface DetectionResultsProps {
  scanResult: ScanResult;
  onReset: () => void;
}

export const DetectionResults: React.FC<DetectionResultsProps> = ({
  scanResult,
  onReset,
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'details'>('overview');
  
  const getThreatLevel = (score: number) => {
    if (score >= 80) return { level: 'High', color: 'text-red-600', bgColor: 'bg-red-100' };
    if (score >= 50) return { level: 'Medium', color: 'text-yellow-600', bgColor: 'bg-yellow-100' };
    return { level: 'Low', color: 'text-green-600', bgColor: 'bg-green-100' };
  };
  
  const threatInfo = getThreatLevel(scanResult.threatScore);
  
  const handleDownloadReport = () => {
    alert('Report downloaded successfully!');
  };
  
  const handleShareReport = () => {
    alert('Report shared successfully!');
  };

  return (
    <div className="bg-white rounded-lg shadow-md">
      <div className="p-6 border-b border-gray-200">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <button 
              onClick={onReset}
              className="mr-4 p-2 rounded-full hover:bg-gray-100"
            >
              <ArrowLeft size={20} />
            </button>
            <h2 className="text-2xl font-bold">Detection Results</h2>
          </div>
          <div className="flex space-x-2">
            <button 
              onClick={handleDownloadReport}
              className="flex items-center px-4 py-2 bg-gray-100 rounded-lg hover:bg-gray-200"
            >
              <Download size={18} className="mr-2" />
              Download
            </button>
            <button 
              onClick={handleShareReport}
              className="flex items-center px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700"
            >
              <Share2 size={18} className="mr-2" />
              Share
            </button>
          </div>
        </div>
      </div>
      
      <div className="p-6">
        <div className="flex flex-col md:flex-row md:space-x-6">
          {/* Image Preview */}
          <div className="md:w-1/2 mb-6 md:mb-0">
            <div className="relative">
              <img 
                src={scanResult.originalImage} 
                alt="Analyzed image" 
                className="w-full h-auto rounded-lg border border-gray-200"
              />
              
              {/* Overlay detection regions */}
              {scanResult.regions.map((region, index) => (
                <div 
                  key={index}
                  className="absolute border-2 border-red-500"
                  style={{
                    left: `${region.x / 5}%`,
                    top: `${region.y / 5}%`,
                    width: `${region.width / 5}%`,
                    height: `${region.height / 5}%`,
                  }}
                >
                  <div className="absolute -top-6 -left-2 bg-red-500 text-white text-xs px-2 py-1 rounded">
                    {region.type} ({Math.round(region.confidence * 100)}%)
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-4 text-sm text-gray-500">
              <div className="flex justify-between">
                <span>Filename: {scanResult.filename}</span>
                <span>Scanned: {new Date(scanResult.timestamp).toLocaleString()}</span>
              </div>
            </div>
          </div>
          
          {/* Results */}
          <div className="md:w-1/2">
            <div className="flex mb-6">
              <button
                onClick={() => setActiveTab('overview')}
                className={`flex-1 py-3 text-center font-medium ${
                  activeTab === 'overview'
                    ? 'text-purple-700 border-b-2 border-purple-700'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                Overview
              </button>
              <button
                onClick={() => setActiveTab('details')}
                className={`flex-1 py-3 text-center font-medium ${
                  activeTab === 'details'
                    ? 'text-purple-700 border-b-2 border-purple-700'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                Technical Details
              </button>
            </div>
            
            {activeTab === 'overview' ? (
              <div>
                <div className={`p-4 rounded-lg mb-6 flex items-center ${threatInfo.bgColor}`}>
                  {scanResult.threatScore >= 50 ? (
                    <AlertTriangle size={24} className={`mr-3 ${threatInfo.color}`} />
                  ) : (
                    <Shield size={24} className="mr-3 text-green-600" />
                  )}
                  <div>
                    <h3 className={`font-bold ${threatInfo.color}`}>
                      {threatInfo.level} Threat Detected
                    </h3>
                    <p className="text-gray-700">
                      {scanResult.threatScore >= 80
                        ? 'This image shows strong signs of face manipulation.'
                        : scanResult.threatScore >= 50
                        ? 'This image shows moderate signs of face manipulation.'
                        : 'This image appears to be authentic.'}
                    </p>
                  </div>
                </div>
                
                <div className="mb-6">
                  <h3 className="text-lg font-semibold mb-3">Threat Assessment</h3>
                  <div className="bg-gray-100 rounded-lg p-4">
                    <div className="mb-4">
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium">Threat Score</span>
                        <span className={`text-sm font-medium ${threatInfo.color}`}>
                          {scanResult.threatScore}/100
                        </span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div 
                          className={`h-2.5 rounded-full ${
                            scanResult.threatScore >= 80
                              ? 'bg-red-600'
                              : scanResult.threatScore >= 50
                              ? 'bg-yellow-500'
                              : 'bg-green-500'
                          }`}
                          style={{ width: `${scanResult.threatScore}%` }}
                        ></div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium">Manipulation Probability</span>
                        <span className="text-sm font-medium">
                          {Math.round(scanResult.manipulationProbability * 100)}%
                        </span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div 
                          className="h-2.5 rounded-full bg-purple-600"
                          style={{ width: `${scanResult.manipulationProbability * 100}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-3">Manipulation Types</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className={`p-3 rounded-lg border ${
                      scanResult.manipulationTypes.faceSwap > 0.5 ? 'border-red-300 bg-red-50' : 'border-gray-200'
                    }`}>
                      <div className="flex justify-between items-center mb-1">
                        <span className="font-medium">Face Swap</span>
                        {scanResult.manipulationTypes.faceSwap > 0.5 ? (
                          <XCircle size={18} className="text-red-500" />
                        ) : (
                          <CheckCircle2 size={18} className="text-green-500" />
                        )}
                      </div>
                      <div className="text-sm">
                        {Math.round(scanResult.manipulationTypes.faceSwap * 100)}% probability
                      </div>
                    </div>
                    
                    <div className={`p-3 rounded-lg border ${
                      scanResult.manipulationTypes.morphing > 0.5 ? 'border-red-300 bg-red-50' : 'border-gray-200'
                    }`}>
                      <div className="flex justify-between items-center mb-1">
                        <span className="font-medium">Morphing</span>
                        {scanResult.manipulationTypes.morphing > 0.5 ? (
                          <XCircle size={18} className="text-red-500" />
                        ) : (
                          <CheckCircle2 size={18} className="text-green-500" />
                        )}
                      </div>
                      <div className="text-sm">
                        {Math.round(scanResult.manipulationTypes.morphing * 100)}% probability
                      </div>
                    </div>
                    
                    <div className={`p-3 rounded-lg border ${
                      scanResult.manipulationTypes.synthesis > 0.5 ? 'border-red-300 bg-red-50' : 'border-gray-200'
                    }`}>
                      <div className="flex justify-between items-center mb-1">
                        <span className="font-medium">Synthesis</span>
                        {scanResult.manipulationTypes.synthesis > 0.5 ? (
                          <XCircle size={18} className="text-red-500" />
                        ) : (
                          <CheckCircle2 size={18} className="text-green-500" />
                        )}
                      </div>
                      <div className="text-sm">
                        {Math.round(scanResult.manipulationTypes.synthesis * 100)}% probability
                      </div>
                    </div>
                    
                    <div className={`p-3 rounded-lg border ${
                      scanResult.manipulationTypes.attributes > 0.5 ? 'border-red-300 bg-red-50' : 'border-gray-200'
                    }`}>
                      <div className="flex justify-between items-center mb-1">
                        <span className="font-medium">Attributes</span>
                        {scanResult.manipulationTypes.attributes > 0.5 ? (
                          <XCircle size={18} className="text-red-500" />
                        ) : (
                          <CheckCircle2 size={18} className="text-green-500" />
                        )}
                      </div>
                      <div className="text-sm">
                        {Math.round(scanResult.manipulationTypes.attributes * 100)}% probability
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div>
                <div className="mb-6">
                  <h3 className="text-lg font-semibold mb-3">Detection Regions</h3>
                  <div className="bg-gray-100 rounded-lg p-4">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b border-gray-200">
                          <th className="text-left py-2">Type</th>
                          <th className="text-left py-2">Coordinates</th>
                          <th className="text-left py-2">Confidence</th>
                        </tr>
                      </thead>
                      <tbody>
                        {scanResult.regions.map((region, index) => (
                          <tr key={index} className="border-b border-gray-200">
                            <td className="py-2 capitalize">{region.type}</td>
                            <td className="py-2">
                              x:{region.x}, y:{region.y}, w:{region.width}, h:{region.height}
                            </td>
                            <td className="py-2">{Math.round(region.confidence * 100)}%</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
                
                <div className="mb-6">
                  <h3 className="text-lg font-semibold mb-3">Analysis Metadata</h3>
                  <div className="bg-gray-100 rounded-lg p-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <div className="text-sm text-gray-500">Scan ID</div>
                        <div className="font-mono">{scanResult.id}</div>
                      </div>
                      <div>
                        <div className="text-sm text-gray-500">Timestamp</div>
                        <div>{new Date(scanResult.timestamp).toLocaleString()}</div>
                      </div>
                      <div>
                        <div className="text-sm text-gray-500">Filename</div>
                        <div>{scanResult.filename}</div>
                      </div>
                      <div>
                        <div className="text-sm text-gray-500">Analysis Version</div>
                        <div>v2.4.1</div>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-3">Technical Notes</h3>
                  <div className="bg-gray-100 rounded-lg p-4">
                    <div className="flex items-start mb-3">
                      <Info size={18} className="text-gray-500 mr-2 mt-0.5" />
                      <div className="text-sm text-gray-700">
                        This analysis was performed using our proprietary deep learning model trained on over 1 million authentic and manipulated facial images.
                      </div>
                    </div>
                    <div className="flex items-start">
                      <Info size={18} className="text-gray-500 mr-2 mt-0.5" />
                      <div className="text-sm text-gray-700">
                        The detection focuses on inconsistencies in facial features, lighting, texture patterns, and metadata that indicate potential manipulation.
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};