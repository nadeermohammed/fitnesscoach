import React, { useState } from 'react';
import { Save, Bell, Shield, Lock, UserCog, RefreshCw } from 'lucide-react';

export const Settings: React.FC = () => {
  const [detectionSettings, setDetectionSettings] = useState({
    sensitivity: 'medium',
    autoScan: true,
    saveScans: true,
    detectionLevel: 'standard',
  });
  
  const [notificationSettings, setNotificationSettings] = useState({
    emailAlerts: true,
    highThreatOnly: false,
    dailySummary: true,
    apiFailures: true,
  });
  
  const handleDetectionChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    const checked = type === 'checkbox' ? (e.target as HTMLInputElement).checked : undefined;
    
    setDetectionSettings({
      ...detectionSettings,
      [name]: type === 'checkbox' ? checked : value,
    });
  };
  
  const handleNotificationChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    
    setNotificationSettings({
      ...notificationSettings,
      [name]: checked,
    });
  };
  
  const handleSaveSettings = () => {
    // In a real app, this would save settings to a backend
    alert('Settings saved successfully!');
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Settings</h2>
          <button
            onClick={handleSaveSettings}
            className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 flex items-center"
          >
            <Save size={18} className="mr-2" />
            Save Changes
          </button>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Detection Settings */}
          <div>
            <div className="flex items-center mb-4">
              <Shield size={20} className="text-purple-600 mr-2" />
              <h3 className="text-lg font-medium">Detection Settings</h3>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Detection Sensitivity
                </label>
                <select
                  name="sensitivity"
                  value={detectionSettings.sensitivity}
                  onChange={handleDetectionChange}
                  className="w-full p-2 border border-gray-300 rounded-md"
                >
                  <option value="low">Low - Fewer false positives</option>
                  <option value="medium">Medium - Balanced detection</option>
                  <option value="high">High - Maximum security</option>
                </select>
                <p className="mt-1 text-sm text-gray-500">
                  Higher sensitivity may increase false positives but catches more potential threats
                </p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Detection Level
                </label>
                <select
                  name="detectionLevel"
                  value={detectionSettings.detectionLevel}
                  onChange={handleDetectionChange}
                  className="w-full p-2 border border-gray-300 rounded-md"
                >
                  <option value="basic">Basic - Fast scanning</option>
                  <option value="standard">Standard - Balanced approach</option>
                  <option value="advanced">Advanced - Deep analysis</option>
                  <option value="forensic">Forensic - Most thorough</option>
                </select>
                <p className="mt-1 text-sm text-gray-500">
                  Higher levels perform more thorough analysis but take longer to process
                </p>
              </div>
              
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="autoScan"
                  name="autoScan"
                  checked={detectionSettings.autoScan}
                  onChange={handleDetectionChange}
                  className="h-4 w-4 text-purple-600 focus:ring-purple-500 border-gray-300 rounded"
                />
                <label htmlFor="autoScan" className="ml-2 block text-sm text-gray-700">
                  Automatically scan uploaded images
                </label>
              </div>
              
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="saveScans"
                  name="saveScans"
                  checked={detectionSettings.saveScans}
                  onChange={handleDetectionChange}
                  className="h-4 w-4 text-purple-600 focus:ring-purple-500 border-gray-300 rounded"
                />
                <label htmlFor="saveScans" className="ml-2 block text-sm text-gray-700">
                  Save scan history
                </label>
              </div>
            </div>
            
            <div className="mt-8">
              <div className="flex items-center mb-4">
                <RefreshCw size={20} className="text-purple-600 mr-2" />
                <h3 className="text-lg font-medium">Model Updates</h3>
              </div>
              
              <div className="bg-gray-100 p-4 rounded-lg">
                <div className="flex justify-between items-center">
                  <div>
                    <div className="font-medium">Detection Model</div>
                    <div className="text-sm text-gray-500">Version 2.4.1 (Latest)</div>
                  </div>
                  <button className="px-3 py-1 bg-purple-100 text-purple-700 rounded hover:bg-purple-200">
                    Check for Updates
                  </button>
                </div>
                <div className="mt-2 text-sm text-gray-600">
                  Last updated: January 5, 2025
                </div>
              </div>
            </div>
          </div>
          
          {/* Notification Settings */}
          <div>
            <div className="flex items-center mb-4">
              <Bell size={20} className="text-purple-600 mr-2" />
              <h3 className="text-lg font-medium">Notification Settings</h3>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="emailAlerts"
                    name="emailAlerts"
                    checked={notificationSettings.emailAlerts}
                    onChange={handleNotificationChange}
                    className="h-4 w-4 text-purple-600 focus:ring-purple-500 border-gray-300 rounded"
                  />
                  <label htmlFor="emailAlerts" className="ml-2 block text-sm text-gray-700">
                    Email alerts for detected threats
                  </label>
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="highThreatOnly"
                    name="highThreatOnly"
                    checked={notificationSettings.highThreatOnly}
                    onChange={handleNotificationChange}
                    className="h-4 w-4 text-purple-600 focus:ring-purple-500 border-gray-300 rounded"
                  />
                  <label htmlFor="highThreatOnly" className="ml-2 block text-sm text-gray-700">
                    Only notify for high-threat detections
                  </label>
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="dailySummary"
                    name="dailySummary"
                    checked={notificationSettings.dailySummary}
                    onChange={handleNotificationChange}
                    className="h-4 w-4 text-purple-600 focus:ring-purple-500 border-gray-300 rounded"
                  />
                  <label htmlFor="dailySummary" className="ml-2 block text-sm text-gray-700">
                    Daily summary report
                  </label>
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="apiFailures"
                    name="apiFailures"
                    checked={notificationSettings.apiFailures}
                    onChange={handleNotificationChange}
                    className="h-4 w-4 text-purple-600 focus:ring-purple-500 border-gray-300 rounded"
                  />
                  <label htmlFor="apiFailures" className="ml-2 block text-sm text-gray-700">
                    API failure notifications
                  </label>
                </div>
              </div>
            </div>
            
            <div className="mt-8">
              <div className="flex items-center mb-4">
                <UserCog size={20} className="text-purple-600 mr-2" />
                <h3 className="text-lg font-medium">Account Settings</h3>
              </div>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    value="admin@company.com"
                    readOnly
                    className="w-full p-2 border border-gray-300 rounded-md bg-gray-50"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Plan
                  </label>
                  <div className="flex justify-between items-center">
                    <div className="font-medium">Professional Plan</div>
                    <button className="text-purple-600 text-sm hover:text-purple-800">
                      Upgrade
                    </button>
                  </div>
                  <div className="mt-1 text-sm text-gray-500">
                    10,000 scans per month, API access, priority support
                  </div>
                </div>
              </div>
            </div>
            
            <div className="mt-8">
              <div className="flex items-center mb-4">
                <Lock size={20} className="text-purple-600 mr-2" />
                <h3 className="text-lg font-medium">Security</h3>
              </div>
              
              <div className="space-y-4">
                <button className="w-full p-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50">
                  Change Password
                </button>
                <button className="w-full p-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50">
                  Enable Two-Factor Authentication
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};