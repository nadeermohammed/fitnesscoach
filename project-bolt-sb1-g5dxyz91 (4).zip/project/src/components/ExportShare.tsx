import React, { useState } from 'react';
import { ClientProfile, WorkoutPlan, NutritionPlan } from '../App';
import { FileText, Mail, Download, Share2 } from 'lucide-react';

interface ExportShareProps {
  clientProfile: ClientProfile | null;
  workoutPlan: WorkoutPlan | null;
  nutritionPlan: NutritionPlan | null;
}

export const ExportShare: React.FC<ExportShareProps> = ({
  clientProfile,
  workoutPlan,
  nutritionPlan,
}) => {
  const [emailAddress, setEmailAddress] = useState('');
  const [emailSent, setEmailSent] = useState(false);
  const [exportFormat, setExportFormat] = useState('pdf');

  const handleExport = () => {
    // In a real application, this would generate a PDF or other format
    // For this prototype, we'll just show an alert
    alert(`Exporting plans in ${exportFormat.toUpperCase()} format...`);
  };

  const handleSendEmail = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real application, this would send an email
    // For this prototype, we'll just show a success message
    setEmailSent(true);
    setTimeout(() => setEmailSent(false), 3000);
  };

  const hasPlans = workoutPlan !== null || nutritionPlan !== null;

  if (!clientProfile) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="text-center py-8">
          <h2 className="text-2xl font-bold mb-4">Export & Share</h2>
          <p className="text-gray-600 mb-4">
            Please complete the client profile first to export or share plans.
          </p>
        </div>
      </div>
    );
  }

  if (!hasPlans) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="text-center py-8">
          <h2 className="text-2xl font-bold mb-4">Export & Share</h2>
          <p className="text-gray-600 mb-4">
            Please generate workout and/or nutrition plans first to export or share them.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold mb-6">Export & Share</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Export Section */}
        <div className="bg-gray-50 p-6 rounded-lg">
          <div className="flex items-center mb-4">
            <Download size={24} className="mr-3 text-blue-600" />
            <h3 className="text-xl font-medium">Export Plans</h3>
          </div>
          
          <p className="text-gray-700 mb-6">
            Export {clientProfile.name}'s personalized plans in your preferred format.
          </p>
          
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Export Format
            </label>
            <div className="flex space-x-4">
              <label className="inline-flex items-center">
                <input
                  type="radio"
                  name="exportFormat"
                  value="pdf"
                  checked={exportFormat === 'pdf'}
                  onChange={() => setExportFormat('pdf')}
                  className="h-4 w-4 text-blue-600 border-gray-300"
                />
                <span className="ml-2 text-gray-700">PDF</span>
              </label>
              <label className="inline-flex items-center">
                <input
                  type="radio"
                  name="exportFormat"
                  value="docx"
                  checked={exportFormat === 'docx'}
                  onChange={() => setExportFormat('docx')}
                  className="h-4 w-4 text-blue-600 border-gray-300"
                />
                <span className="ml-2 text-gray-700">DOCX</span>
              </label>
              <label className="inline-flex items-center">
                <input
                  type="radio"
                  name="exportFormat"
                  value="csv"
                  checked={exportFormat === 'csv'}
                  onChange={() => setExportFormat('csv')}
                  className="h-4 w-4 text-blue-600 border-gray-300"
                />
                <span className="ml-2 text-gray-700">CSV</span>
              </label>
            </div>
          </div>
          
          <div className="space-y-4">
            {workoutPlan && (
              <button
                onClick={handleExport}
                className="flex items-center w-full px-4 py-3 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
              >
                <FileText size={20} className="mr-3 text-blue-600" />
                <span>Export Workout Plan</span>
              </button>
            )}
            
            {nutritionPlan && (
              <button
                onClick={handleExport}
                className="flex items-center w-full px-4 py-3 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
              >
                <FileText size={20} className="mr-3 text-blue-600" />
                <span>Export Nutrition Plan</span>
              </button>
            )}
            
            {workoutPlan && nutritionPlan && (
              <button
                onClick={handleExport}
                className="flex items-center w-full px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                <Download size={20} className="mr-3" />
                <span>Export Complete Package</span>
              </button>
            )}
          </div>
        </div>
        
        {/* Share Section */}
        <div className="bg-gray-50 p-6 rounded-lg">
          <div className="flex items-center mb-4">
            <Share2 size={24} className="mr-3 text-blue-600" />
            <h3 className="text-xl font-medium">Share Plans</h3>
          </div>
          
          <p className="text-gray-700 mb-6">
            Share {clientProfile.name}'s personalized plans directly via email.
          </p>
          
          <form onSubmit={handleSendEmail}>
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Recipient Email
              </label>
              <input
                type="email"
                value={emailAddress}
                onChange={(e) => setEmailAddress(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg"
                placeholder="client@example.com"
                required
              />
            </div>
            
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Plans to Share
              </label>
              <div className="space-y-2">
                {workoutPlan && (
                  <label className="inline-flex items-center block">
                    <input
                      type="checkbox"
                      checked={true}
                      readOnly
                      className="h-4 w-4 text-blue-600 border-gray-300 rounded"
                    />
                    <span className="ml-2 text-gray-700">Workout Plan</span>
                  </label>
                )}
                
                {nutritionPlan && (
                  <label className="inline-flex items-center block">
                    <input
                      type="checkbox"
                      checked={true}
                      readOnly
                      className="h-4 w-4 text-blue-600 border-gray-300 rounded"
                    />
                    <span className="ml-2 text-gray-700">Nutrition Plan</span>
                  </label>
                )}
              </div>
            </div>
            
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Message (Optional)
              </label>
              <textarea
                className="w-full p-3 border border-gray-300 rounded-lg"
                rows={3}
                placeholder="Here's your personalized fitness plan as we discussed..."
              ></textarea>
            </div>
            
            <button
              type="submit"
              className="flex items-center w-full justify-center px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Mail size={20} className="mr-3" />
              <span>Send Email</span>
            </button>
            
            {emailSent && (
              <div className="mt-4 p-3 bg-green-100 text-green-800 rounded-lg">
                Email sent successfully!
              </div>
            )}
          </form>
        </div>
      </div>
    </div>
  );
};