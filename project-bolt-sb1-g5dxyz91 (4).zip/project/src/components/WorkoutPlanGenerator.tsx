import React, { useState } from 'react';
import { ClientProfile, WorkoutPlan } from '../App';
import { Dumbbell } from 'lucide-react';

interface WorkoutPlanGeneratorProps {
  clientProfile: ClientProfile | null;
  workoutPlan: WorkoutPlan | null;
  setWorkoutPlan: (plan: WorkoutPlan) => void;
}

export const WorkoutPlanGenerator: React.FC<WorkoutPlanGeneratorProps> = ({
  clientProfile,
  workoutPlan,
  setWorkoutPlan,
}) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [workoutDays, setWorkoutDays] = useState(4);

  // Mock function to simulate AI-generated workout plan
  const generateWorkoutPlan = () => {
    if (!clientProfile) {
      alert('Please complete the client profile first!');
      return;
    }

    setIsGenerating(true);

    // Simulate API call delay
    setTimeout(() => {
      const mockExercises = {
        beginner: [
          { name: 'Bodyweight Squats', sets: 3, reps: 12, rest: 60 },
          { name: 'Push-ups', sets: 3, reps: 10, rest: 60 },
          { name: 'Walking Lunges', sets: 2, reps: 10, rest: 60 },
          { name: 'Plank', sets: 3, reps: 1, rest: 60, notes: 'Hold for 30 seconds' },
          { name: 'Glute Bridges', sets: 3, reps: 12, rest: 60 },
        ],
        intermediate: [
          { name: 'Goblet Squats', sets: 4, reps: 12, rest: 60 },
          { name: 'Dumbbell Bench Press', sets: 4, reps: 10, rest: 90 },
          { name: 'Romanian Deadlifts', sets: 3, reps: 12, rest: 90 },
          { name: 'Bent-Over Rows', sets: 3, reps: 12, rest: 90 },
          { name: 'Lateral Raises', sets: 3, reps: 15, rest: 60 },
          { name: 'Hanging Leg Raises', sets: 3, reps: 12, rest: 60 },
        ],
        advanced: [
          { name: 'Barbell Back Squats', sets: 5, reps: 5, rest: 120 },
          { name: 'Bench Press', sets: 5, reps: 5, rest: 120 },
          { name: 'Deadlifts', sets: 5, reps: 5, rest: 180 },
          { name: 'Pull-ups', sets: 4, reps: 8, rest: 90 },
          { name: 'Overhead Press', sets: 4, reps: 8, rest: 90 },
          { name: 'Barbell Rows', sets: 4, reps: 8, rest: 90 },
          { name: 'Hanging Leg Raises', sets: 4, reps: 12, rest: 60 },
        ],
      };

      const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
      const workoutSplit = {
        beginner: ['Full Body', 'Rest', 'Full Body', 'Rest', 'Full Body', 'Rest', 'Rest'],
        intermediate: ['Upper Body', 'Lower Body', 'Rest', 'Upper Body', 'Lower Body', 'Rest', 'Rest'],
        advanced: ['Push', 'Pull', 'Legs', 'Rest', 'Push', 'Pull', 'Rest'],
      };

      // Generate workout plan based on fitness level
      const level = clientProfile.fitnessLevel as keyof typeof mockExercises;
      const exercises = mockExercises[level];
      const split = workoutSplit[level];

      const generatedPlan: WorkoutPlan = {
        days: days.slice(0, workoutDays).map((day, index) => {
          const dayType = split[index];
          
          if (dayType === 'Rest') {
            return {
              day,
              exercises: [],
            };
          }

          // Filter exercises based on available equipment
          let availableExercises = [...exercises];
          if (!clientProfile.availableEquipment.includes('full gym')) {
            availableExercises = availableExercises.filter(ex => 
              !ex.name.toLowerCase().includes('barbell') || 
              clientProfile.availableEquipment.includes('barbell')
            );
          }

          // Shuffle and pick exercises
          const shuffled = [...availableExercises].sort(() => 0.5 - Math.random());
          const selectedExercises = shuffled.slice(0, 4 + Math.floor(Math.random() * 3));

          return {
            day,
            exercises: selectedExercises,
          };
        }),
      };

      setWorkoutPlan(generatedPlan);
      setIsGenerating(false);
    }, 2000);
  };

  if (!clientProfile) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="text-center py-8">
          <h2 className="text-2xl font-bold mb-4">Workout Plan Generator</h2>
          <p className="text-gray-600 mb-4">
            Please complete the client profile first to generate a workout plan.
          </p>
          <button
            onClick={() => {}}
            className="px-6 py-3 bg-gray-400 text-white font-medium rounded-lg cursor-not-allowed"
            disabled
          >
            Generate Workout Plan
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold mb-6">Workout Plan Generator</h2>
      
      {!workoutPlan ? (
        <div>
          <div className="mb-6">
            <p className="text-gray-700 mb-4">
              Generate a personalized workout plan for {clientProfile.name} based on their profile information.
            </p>
            
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Number of Workout Days Per Week
              </label>
              <select
                value={workoutDays}
                onChange={(e) => setWorkoutDays(parseInt(e.target.value))}
                className="w-full md:w-1/3 p-2 border border-gray-300 rounded-md"
              >
                {[3, 4, 5, 6].map((num) => (
                  <option key={num} value={num}>
                    {num} days
                  </option>
                ))}
              </select>
            </div>
            
            <div className="mt-6">
              <button
                onClick={generateWorkoutPlan}
                className="px-6 py-3 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors flex items-center"
                disabled={isGenerating}
              >
                {isGenerating ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Generating...
                  </>
                ) : (
                  <>
                    <Dumbbell className="mr-2" size={20} />
                    Generate Workout Plan
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div>
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-xl font-semibold">
              {clientProfile.name}'s Workout Plan
            </h3>
            <button
              onClick={() => setWorkoutPlan(null)}
              className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors"
            >
              Reset
            </button>
          </div>
          
          <div className="space-y-6">
            {workoutPlan.days.map((day, dayIndex) => (
              <div key={dayIndex} className="border border-gray-200 rounded-lg overflow-hidden">
                <div className="bg-gray-100 px-4 py-3 font-medium">
                  {day.day}
                </div>
                
                {day.exercises.length === 0 ? (
                  <div className="p-4 text-center text-gray-500">
                    Rest Day
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Exercise
                          </th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Sets
                          </th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Reps
                          </th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Rest (sec)
                          </th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Notes
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {day.exercises.map((exercise, exIndex) => (
                          <tr key={exIndex}>
                            <td className="px-4 py-3 whitespace-nowrap">
                              {exercise.name}
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap">
                              {exercise.sets}
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap">
                              {exercise.reps}
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap">
                              {exercise.rest}
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap text-gray-500">
                              {exercise.notes || '-'}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};