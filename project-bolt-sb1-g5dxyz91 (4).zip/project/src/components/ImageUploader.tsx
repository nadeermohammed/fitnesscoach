import React, { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, FileImage, FileVideo, AlertCircle } from 'lucide-react';

interface ImageUploaderProps {
  onScan: (file: File, type: 'image' | 'video') => void;
}

export const ImageUploader: React.FC<ImageUploaderProps> = ({ onScan }) => {
  const [files, setFiles] = useState<File[]>([]);
  const [fileType, setFileType] = useState<'image' | 'video'>('image');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    setError(null);
    
    // Check if files were dropped
    if (acceptedFiles.length === 0) {
      return;
    }
    
    // Check file type
    const file = acceptedFiles[0];
    if (fileType === 'image' && !file.type.startsWith('image/')) {
      setError('Please upload an image file (JPEG, PNG, etc.)');
      return;
    }
    
    if (fileType === 'video' && !file.type.startsWith('video/')) {
      setError('Please upload a video file (MP4, WebM, etc.)');
      return;
    }
    
    setFiles(acceptedFiles);
  }, [fileType]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({ 
    onDrop,
    accept: fileType === 'image' 
      ? { 'image/*': ['.jpeg', '.jpg', '.png', '.gif'] }
      : { 'video/*': ['.mp4', '.webm', '.mov'] },
    maxFiles: 1,
  });

  const handleScan = () => {
    if (files.length === 0) {
      setError('Please upload a file first');
      return;
    }
    
    setIsLoading(true);
    
    // Simulate API call delay
    setTimeout(() => {
      onScan(files[0], fileType);
      setIsLoading(false);
    }, 2000);
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold mb-6">Upload & Scan</h2>
      
      <div className="mb-6">
        <div className="flex space-x-4 mb-6">
          <button
            onClick={() => setFileType('image')}
            className={`flex items-center px-4 py-2 rounded-lg ${
              fileType === 'image'
                ? 'bg-purple-100 text-purple-700 border border-purple-300'
                : 'bg-gray-100 text-gray-700 border border-gray-300'
            }`}
          >
            <FileImage size={20} className="mr-2" />
            Image
          </button>
          <button
            onClick={() => setFileType('video')}
            className={`flex items-center px-4 py-2 rounded-lg ${
              fileType === 'video'
                ? 'bg-purple-100 text-purple-700 border border-purple-300'
                : 'bg-gray-100 text-gray-700 border border-gray-300'
            }`}
          >
            <FileVideo size={20} className="mr-2" />
            Video
          </button>
        </div>
        
        <div 
          {...getRootProps()} 
          className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors ${
            isDragActive 
              ? 'border-purple-400 bg-purple-50' 
              : 'border-gray-300 hover:border-purple-400 hover:bg-purple-50'
          }`}
        >
          <input {...getInputProps()} />
          <Upload size={48} className="mx-auto text-gray-400 mb-4" />
          
          {files.length > 0 ? (
            <div>
              <p className="text-sm text-gray-600 mb-2">Selected file:</p>
              <p className="font-medium">{files[0].name}</p>
              <p className="text-sm text-gray-500 mt-1">
                {(files[0].size / 1024 / 1024).toFixed(2)} MB
              </p>
            </div>
          ) : (
            <div>
              <p className="text-lg font-medium mb-1">
                Drag & drop a {fileType} here, or click to select
              </p>
              <p className="text-sm text-gray-500">
                {fileType === 'image' 
                  ? 'Supports JPEG, PNG, and GIF files up to 10MB' 
                  : 'Supports MP4, WebM, and MOV files up to 100MB'}
              </p>
            </div>
          )}
        </div>
        
        {error && (
          <div className="mt-4 p-3 bg-red-100 text-red-700 rounded-lg flex items-start">
            <AlertCircle size={20} className="mr-2 flex-shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}
      </div>
      
      <div className="flex justify-between items-center">
        <div className="text-sm text-gray-500">
          {fileType === 'image' 
            ? 'Our AI will analyze the image for signs of face morphing or manipulation' 
            : 'Our AI will analyze each frame of the video for signs of face morphing or manipulation'}
        </div>
        <button
          onClick={handleScan}
          disabled={files.length === 0 || isLoading}
          className={`px-6 py-3 rounded-lg font-medium flex items-center ${
            files.length === 0 || isLoading
              ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
              : 'bg-purple-600 text-white hover:bg-purple-700'
          }`}
        >
          {isLoading ? (
            <>
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Analyzing...
            </>
          ) : (
            <>
              Scan {fileType}
            </>
          )}
        </button>
      </div>
    </div>
  );
};