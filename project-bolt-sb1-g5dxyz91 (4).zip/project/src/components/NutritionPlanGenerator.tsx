import React, { useState } from 'react';
import { ClientProfile, NutritionPlan } from '../App';
import { Utensils } from 'lucide-react';

interface NutritionPlanGeneratorProps {
  clientProfile: ClientProfile | null;
  nutritionPlan: NutritionPlan | null;
  setNutritionPlan: (plan: NutritionPlan) => void;
}

export const NutritionPlanGenerator: React.FC<NutritionPlanGeneratorProps> = ({
  clientProfile,
  nutritionPlan,
  setNutritionPlan,
}) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [mealsPerDay, setMealsPerDay] = useState(4);

  // Calculate BMR (Basal Metabolic Rate) using Mifflin-St Jeor Equation
  const calculateBMR = (profile: ClientProfile): number => {
    const { weight, height, age, gender } = profile;
    
    if (gender === 'male') {
      return 10 * weight + 6.25 * height - 5 * age + 5;
    } else {
      return 10 * weight + 6.25 * height - 5 * age - 161;
    }
  };

  // Calculate TDEE (Total Daily Energy Expenditure)
  const calculateTDEE = (bmr: number, activityLevel: string): number => {
    const activityMultipliers: Record<string, number> = {
      'beginner': 1.375, // Light activity
      'intermediate': 1.55, // Moderate activity
      'advanced': 1.725, // Very active
    };
    
    return Math.round(bmr * activityMultipliers[activityLevel]);
  };

  // Calculate target calories based on goals
  const calculateTargetCalories = (tdee: number, goals: string[]): number => {
    if (goals.includes('weight loss')) {
      return Math.round(tdee * 0.8); // 20% deficit
    } else if (goals.includes('muscle gain')) {
      return Math.round(tdee * 1.1); // 10% surplus
    } else {
      return tdee; // Maintenance
    }
  };

  // Mock function to simulate AI-generated nutrition plan
  const generateNutritionPlan = () => {
    if (!clientProfile) {
      alert('Please complete the client profile first!');
      return;
    }

    setIsGenerating(true);

    // Simulate API call delay
    setTimeout(() => {
      const bmr = calculateBMR(clientProfile);
      const tdee = calculateTDEE(bmr, clientProfile.fitnessLevel);
      const targetCalories = calculateTargetCalories(tdee, clientProfile.goals);
      
      // Calculate macros based on goals
      let proteinPercentage = 0.3; // 30% protein
      let carbsPercentage = 0.4; // 40% carbs
      let fatsPercentage = 0.3; // 30% fats
      
      if (clientProfile.goals.includes('muscle gain')) {
        proteinPercentage = 0.35;
        carbsPercentage = 0.45;
        fatsPercentage = 0.2;
      } else if (clientProfile.goals.includes('weight loss')) {
        proteinPercentage = 0.4;
        carbsPercentage = 0.3;
        fatsPercentage = 0.3;
      }
      
      const proteinGrams = Math.round((targetCalories * proteinPercentage) / 4); // 4 calories per gram
      const carbsGrams = Math.round((targetCalories * carbsPercentage) / 4); // 4 calories per gram
      const fatsGrams = Math.round((targetCalories * fatsPercentage) / 9); // 9 calories per gram
      
      // Sample food database
      const foodDatabase = {
        proteins: [
          { name: 'Chicken Breast', portion: '100g', calories: 165, protein: 31, carbs: 0, fats: 3.6 },
          { name: 'Salmon', portion: '100g', calories: 206, protein: 22, carbs: 0, fats: 13 },
          { name: 'Greek Yogurt', portion: '200g', calories: 130, protein: 22, carbs: 8, fats: 0 },
          { name: 'Eggs', portion: '2 large', calories: 156, protein: 13, carbs: 1, fats: 11 },
          { name: 'Tofu', portion: '100g', calories: 144, protein: 17, carbs: 3, fats: 8 },
          { name: 'Lean Beef', portion: '100g', calories: 250, protein: 26, carbs: 0, fats: 17 },
        ],
        carbs: [
          { name: 'Brown Rice', portion: '100g cooked', calories: 112, protein: 2.6, carbs: 23, fats: 0.9 },
          { name: 'Sweet Potato', portion: '1 medium', calories: 112, protein: 2, carbs: 26, fats: 0.1 },
          { name: 'Quinoa', portion: '100g cooked', calories: 120, protein: 4.4, carbs: 21, fats: 1.9 },
          { name: 'Oatmeal', portion: '50g dry', calories: 190, protein: 7, carbs: 33, fats: 3.5 },
          { name: 'Whole Wheat Bread', portion: '2 slices', calories: 160, protein: 8, carbs: 30, fats: 2 },
          { name: 'Banana', portion: '1 medium', calories: 105, protein: 1.3, carbs: 27, fats: 0.4 },
        ],
        fats: [
          { name: 'Avocado', portion: '1/2 medium', calories: 160, protein: 2, carbs: 8, fats: 15 },
          { name: 'Olive Oil', portion: '1 tbsp', calories: 119, protein: 0, carbs: 0, fats: 14 },
          { name: 'Almonds', portion: '30g', calories: 170, protein: 6, carbs: 6, fats: 15 },
          { name: 'Peanut Butter', portion: '2 tbsp', calories: 190, protein: 8, carbs: 7, fats: 16 },
          { name: 'Chia Seeds', portion: '2 tbsp', calories: 140, protein: 5, carbs: 12, fats: 9 },
        ],
        vegetables: [
          { name: 'Broccoli', portion: '100g', calories: 34, protein: 2.8, carbs: 7, fats: 0.4 },
          { name: 'Spinach', portion: '100g', calories: 23, protein: 2.9, carbs: 3.6, fats: 0.4 },
          { name: 'Bell Peppers', portion: '1 medium', calories: 30, protein: 1, carbs: 7, fats: 0.3 },
          { name: 'Carrots', portion: '100g', calories: 41, protein: 0.9, carbs: 10, fats: 0.2 },
        ],
      };
      
      // Filter foods based on dietary restrictions
      let availableProteins = [...foodDatabase.proteins];
      let availableCarbs = [...foodDatabase.carbs];
      let availableFats = [...foodDatabase.fats];
      
      if (clientProfile.dietaryRestrictions.includes('vegetarian')) {
        availableProteins = availableProteins.filter(food => 
          !['Chicken Breast', 'Salmon', 'Lean Beef'].includes(food.name)
        );
      }
      
      if (clientProfile.dietaryRestrictions.includes('vegan')) {
        availableProteins = availableProteins.filter(food => 
          !['Chicken Breast', 'Salmon', 'Greek Yogurt', 'Eggs', 'Lean Beef'].includes(food.name)
        );
      }
      
      if (clientProfile.dietaryRestrictions.includes('dairy-free')) {
        availableProteins = availableProteins.filter(food => food.name !== 'Greek Yogurt');
      }
      
      // Generate meal plan
      const mealNames = ['Breakfast', 'Lunch', 'Dinner', 'Snack 1', 'Snack 2', 'Snack 3'];
      const meals = [];
      
      const caloriesPerMeal = Math.round(targetCalories / mealsPerDay);
      
      for (let i = 0; i < mealsPerDay; i++) {
        const mealName = mealNames[i];
        const mealFoods = [];
        
        // Add protein
        const protein = availableProteins[Math.floor(Math.random() * availableProteins.length)];
        mealFoods.push(protein);
        
        // Add carbs
        const carb = availableCarbs[Math.floor(Math.random() * availableCarbs.length)];
        mealFoods.push(carb);
        
        // Add fat
        const fat = availableFats[Math.floor(Math.random() * availableFats.length)];
        mealFoods.push(fat);
        
        // Add vegetable
        const vegetable = foodDatabase.vegetables[Math.floor(Math.random() * foodDatabase.vegetables.length)];
        mealFoods.push(vegetable);
        
        meals.push({
          name: mealName,
          foods: mealFoods,
        });
      }
      
      const generatedPlan: NutritionPlan = {
        dailyCalories: targetCalories,
        macros: {
          protein: proteinGrams,
          carbs: carbsGrams,
          fats: fatsGrams,
        },
        meals,
      };
      
      setNutritionPlan(generatedPlan);
      setIsGenerating(false);
    }, 2000);
  };

  if (!clientProfile) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="text-center py-8">
          <h2 className="text-2xl font-bold mb-4">Nutrition Plan Generator</h2>
          <p className="text-gray-600 mb-4">
            Please complete the client profile first to generate a nutrition plan.
          </p>
          <button
            onClick={() => {}}
            className="px-6 py-3 bg-gray-400 text-white font-medium rounded-lg cursor-not-allowed"
            disabled
          >
            Generate Nutrition Plan
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold mb-6">Nutrition Plan Generator</h2>
      
      {!nutritionPlan ? (
        <div>
          <div className="mb-6">
            <p className="text-gray-700 mb-4">
              Generate a personalized nutrition plan for {clientProfile.name} based on their profile information.
            </p>
            
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Number of Meals Per Day
              </label>
              <select
                value={mealsPerDay}
                onChange={(e) => setMealsPerDay(parseInt(e.target.value))}
                className="w-full md:w-1/3 p-2 border border-gray-300 rounded-md"
              >
                {[3, 4, 5, 6].map((num) => (
                  <option key={num} value={num}>
                    {num} meals
                  </option>
                ))}
              </select>
            </div>
            
            <div className="mt-6">
              <button
                onClick={generateNutritionPlan}
                className="px-6 py-3 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors flex items-center"
                disabled={isGenerating}
              >
                {isGenerating ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Generating...
                  </>
                ) : (
                  <>
                    <Utensils className="mr-2" size={20} />
                    Generate Nutrition Plan
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div>
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-xl font-semibold">
              {clientProfile.name}'s Nutrition Plan
            </h3>
            <button
              onClick={() => setNutritionPlan(null)}
              className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors"
            >
              Reset
            </button>
          </div>
          
          <div className="bg-blue-50 p-4 rounded-lg mb-6">
            <h4 className="font-medium text-blue-800 mb-2">Daily Nutrition Summary</h4>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-white p-3 rounded-lg shadow-sm">
                <div className="text-sm text-gray-500">Daily Calories</div>
                <div className="text-xl font-bold">{nutritionPlan.dailyCalories} kcal</div>
              </div>
              <div className="bg-white p-3 rounded-lg shadow-sm">
                <div className="text-sm text-gray-500">Protein</div>
                <div className="text-xl font-bold">{nutritionPlan.macros.protein}g</div>
              </div>
              <div className="bg-white p-3 rounded-lg shadow-sm">
                <div className="text-sm text-gray-500">Carbs</div>
                <div className="text-xl font-bold">{nutritionPlan.macros.carbs}g</div>
              </div>
              <div className="bg-white p-3 rounded-lg shadow-sm">
                <div className="text-sm text-gray-500">Fats</div>
                <div className="text-xl font-bold">{nutritionPlan.macros.fats}g</div>
              </div>
            </div>
          </div>
          
          <div className="space-y-6">
            {nutritionPlan.meals.map((meal, mealIndex) => (
              <div key={mealIndex} className="border border-gray-200 rounded-lg overflow-hidden">
                <div className="bg-gray-100 px-4 py-3 font-medium">
                  {meal.name}
                </div>
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Food
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Portion
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Calories
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Protein
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Carbs
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Fats
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {meal.foods.map((food, foodIndex) => (
                        <tr key={foodIndex}>
                          <td className="px-4 py-3 whitespace-nowrap">
                            {food.name}
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap">
                            {food.portion}
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap">
                            {food.calories} kcal
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap">
                            {food.protein}g
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap">
                            {food.carbs}g
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap">
                            {food.fats}g
                          </td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot className="bg-gray-50">
                      <tr>
                        <td className="px-4 py-3 whitespace-nowrap font-medium">
                          Total
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap font-medium">
                          {meal.foods.reduce((sum, food) => sum + food.calories, 0)} kcal
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap font-medium">
                          {meal.foods.reduce((sum, food) => sum + food.protein, 0)}g
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap font-medium">
                          {meal.foods.reduce((sum, food) => sum + food.carbs, 0)}g
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap font-medium">
                          {meal.foods.reduce((sum, food) => sum + food.fats, 0)}g
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};